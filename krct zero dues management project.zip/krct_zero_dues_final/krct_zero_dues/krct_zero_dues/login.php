<?php
session_start(); // Start the session

// Check if user is already logged in
if (isset($_SESSION["username"])) {
    header("Location: welcome.php"); // Redirect if logged in
    exit;
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve username and password from form
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Database connection
    $servername = "localhost";
    $db_username = "root";
    $db_password = "";
    $dbname = "krctnodues";

    // Create connection
    $conn = new mysqli($servername, $db_username, $db_password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare("SELECT username, password FROM login1 WHERE username = ?");
    $stmt->bind_param("s", $username); // Bind parameters
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if user exists
    if ($result->num_rows > 0) {
        // Fetch user details
        $row = $result->fetch_assoc();
        
        // Verify password (assuming passwords are hashed using password_hash())
        if (password_verify($password, $row['password'])) {
            // Set session variables for logged-in user
            $_SESSION["username"] = $username;
            
            // Redirect to welcome page
            header("Location: welcome.php");
            exit;
        } else {
            echo '<script>alert("Invalid username or password.");</script>';
        }
    } else {
        echo '<script>alert("User not found.");</script>';
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>

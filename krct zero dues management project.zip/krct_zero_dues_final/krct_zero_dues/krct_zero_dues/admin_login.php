<?php
session_start(); // Start the session

// Check if admin is already logged in
if (isset($_SESSION["admin_username"])) {
    header("Location: admin_dashboard.php"); // Redirect if logged in
    exit;
}

// Initialize error message variable
$error_message = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve username and password from form
    $admin_username = $_POST["admin_username"];
    $admin_password = $_POST["admin_password"];

    // Database connection
    $servername = "localhost";
    $db_username = "root";
    $db_password = "";
    $dbname = "krctnodues";

    // Create connection
    $conn = new mysqli($servername, $db_username, $db_password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare("SELECT admin_username, admin_password FROM admin_login WHERE admin_username = ?");
    $stmt->bind_param("s", $admin_username); // Bind parameters
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if admin exists
    if ($result->num_rows > 0) {
        // Fetch admin details
        $row = $result->fetch_assoc();
        
        // Verify password (assuming passwords are hashed using password_hash())
       // Check if the provided password matches the stored password
if ($admin_password === $row['admin_password']) {
    // Set session variables for logged-in admin
    $_SESSION["admin_username"] = $admin_username;

    // Redirect to admin dashboard
    header("Location: admin_dashboard.php");
    exit;
} else {
    $error_message = "Invalid username or password.";
}

    } else {
        $error_message = "Admin not found.";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
    <title>Admin Login</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f0f0f0;
        }
        .login-box {
            width: 300px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            text-align: center;
            background-color: white;
        }
        .login-box input[type="text"],
        .login-box input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }
        .login-box input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .error-message {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <h2>Admin Login</h2>
        <form action="admin_login.php" method="POST">
            <input type="text" name="admin_username" placeholder="Enter Admin Username" required>
            <input type="password" name="admin_password" placeholder="Enter Admin Password" required>
            <input type="submit" value="Login">
        </form>
        <?php if (!empty($error_message)): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>
    </div>
</body>
</html>

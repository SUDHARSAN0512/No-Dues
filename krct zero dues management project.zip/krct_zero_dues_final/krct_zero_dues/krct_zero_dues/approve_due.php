


<?php
session_start();
require 'C:\xampp\htdocs\krct_zero_dues_final\krct_zero_dues\vendor\autoload.php'; // Include Composer's autoloader
require('C:\xampp\htdocs\krct_zero_dues_final\krct_zero_dues\krct_zero_dues\fpdf186\fpdf.php'); // Include TCPDF for PDF generation

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Function to convert numbers to words (Example logic; adjust as needed)
function numberToWords($num) {
    $ones = array(
        0 => "ZERO", 1 => "ONE", 2 => "TWO", 3 => "THREE", 4 => "FOUR", 5 => "FIVE", 6 => "SIX", 7 => "SEVEN", 8 => "EIGHT", 9 => "NINE",
        10 => "TEN", 11 => "ELEVEN", 12 => "TWELVE", 13 => "THIRTEEN", 14 => "FOURTEEN", 15 => "FIFTEEN", 16 => "SIXTEEN", 17 => "SEVENTEEN", 18 => "EIGHTEEN", 19 => "NINETEEN"
    );

    $tens = array(
        0 => "", 1 => "TEN", 2 => "TWENTY", 3 => "THIRTY", 4 => "FORTY", 5 => "FIFTY", 6 => "SIXTY", 7 => "SEVENTY", 8 => "EIGHTY", 9 => "NINETY"
    );

    $hundreds = array(
        "HUNDRED", "THOUSAND", "MILLION", "BILLION", "TRILLION", "QUADRILLION"
    );

    $num = number_format($num, 2, ".", ",");
    $num_arr = explode(".", $num);
    $wholenum = $num_arr[0];
    $decnum = $num_arr[1];
    $whole_arr = array_reverse(explode(",", $wholenum));
    krsort($whole_arr, 1);
    $rettxt = "";

    foreach ($whole_arr as $key => $i) {
        while (substr($i, 0, 1) == "0")
            $i = substr($i, 1, 5);
        if ($i < 20) {
            if ($i != 0) {
                $rettxt .= $ones[$i];
            }
        } elseif ($i < 100) {
            $rettxt .= $tens[substr($i, 0, 1)];
            if (substr($i, 1, 1) != "0") {
                $rettxt .= " " . $ones[substr($i, 1, 1)];
            }
        } else {
            $rettxt .= $ones[substr($i, 0, 1)] . " " . $hundreds[0];
            if (substr($i, 1, 1) != "0") {
                $rettxt .= " " . $tens[substr($i, 1, 1)];
            }
            if (substr($i, 2, 1) != "0") {
                $rettxt .= " " . $ones[substr($i, 2, 1)];
            }
        }
        if ($key > 0 && trim($rettxt) != "") {
            $rettxt .= " " . $hundreds[$key] . " ";
        }
    }

    if ($decnum > 0) {
        $rettxt .= " AND ";
        if ($decnum < 20) {
            $rettxt .= $ones[$decnum];
        } elseif ($decnum < 100) {
            $rettxt .= $tens[substr($decnum, 0, 1)];
            if (substr($decnum, 1, 1) != "0") {
                $rettxt .= " " . $ones[substr($decnum, 1, 1)];
            }
        }
    } else {
        $rettxt .= " ONLY";
    }

    return $rettxt;
}




// Function to generate password-protected PDF using TCPDF
function generateProtectedPDF($name, $department, $tutionfee, $hostelfee, $busfee, $miscellaneousfee, $mess_fee, $exam_fee, $library_fee, $fine, $total_amount, $total_amount_in_words, $birth_year) {
    $pdf = new TCPDF();

    // Add a page and set margins
    $pdf->AddPage();
    $pdf->SetMargins(10, 10, 10); // Small margins for more space

    // Fetch today's date
    $current_date = date(format: "d-m-Y"); // Format: Day-Month-Year

    // Add current date at the top right corner
    $pdf->SetFont('helvetica', '', 10);
    $pdf->Cell(0, 10, "Date: $current_date", 0, 1, 'R'); // Aligned to the right

    // Title at the very top
    $pdf->SetFont('helvetica', 'B', 14); 
    $pdf->Cell(0, 10, 'No Due Form', 0, 1, 'C'); // Centered title

    // Add some vertical space after the title
    $pdf->Ln(5);

    // Set smaller font for the table content
    $pdf->SetFont('helvetica', '', 10);

    // Adjust the table's position to the center of the page
    $table_start_y = 50; // Adjust this value to move the table
    $pdf->SetY($table_start_y);

    // Set column widths
    $width_col1 = 50; // Column width for labels
    $width_col2 = 60; // Column width for values

    // Add the table content
    $pdf->Cell($width_col1, 8, 'Name:', 1);
    $pdf->Cell($width_col2, 8, $name, 1, 1);

    $pdf->Cell($width_col1, 8, 'Tuition Fee:', 1);
    $pdf->Cell($width_col2, 8, $tutionfee, 1, 1);

    $pdf->Cell($width_col1, 8, 'Hostel Fee:', 1);
    $pdf->Cell($width_col2, 8, $hostelfee, 1, 1);

    $pdf->Cell($width_col1, 8, 'Bus Fee:', 1);
    $pdf->Cell($width_col2, 8, $busfee, 1, 1);

    $pdf->Cell($width_col1, 8, 'Miscellaneous Fee:', 1);
    $pdf->Cell($width_col2, 8, $miscellaneousfee, 1, 1);

    $pdf->Cell($width_col1, 8, 'Mess Fee:', 1);
    $pdf->Cell($width_col2, 8, $mess_fee, 1, 1);

    $pdf->Cell($width_col1, 8, 'Exam Fee:', 1);
    $pdf->Cell($width_col2, 8, $exam_fee, 1, 1);

    $pdf->Cell($width_col1, 8, 'Library Fee:', 1);
    $pdf->Cell($width_col2, 8, $library_fee, 1, 1);

    $pdf->Cell($width_col1, 8, 'Fine:', 1);
    $pdf->Cell($width_col2, 8, $fine, 1, 1);

    $pdf->Cell($width_col1, 8, 'Total Fee:', 1);
    $pdf->Cell($width_col2, 8, $total_amount, 1, 1);

    $pdf->Cell($width_col1, 8, 'Total in Words:', 1);
    $pdf->Cell($width_col2, 8, $total_amount_in_words, 1, 1);

    // Add some space before signatures
    $pdf->Ln(10);

    // Add signatures
    $pdf->Cell(0, 8, 'Student Signature', 0, 1, 'L');
    $pdf->Cell(0, 8, 'Staff Signature', 0, 1, 'R');

    // Add approval status
    $pdf->Ln(5);
    if ($fine == 0) {
        $pdf->SetTextColor(0, 255, 0); // Green text
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(0, 10, 'APPROVED', 0, 1, 'C');
    } else {
        $pdf->SetTextColor(255, 0, 0); // Red text
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(0, 10, 'NOT APPROVED', 0, 1, 'C');
    }

    // Password logic
    $password = strtoupper(substr(trim($name), 0, 3)) . trim($birth_year);
    $pdf->SetProtection(['copy', 'print'], $password, $password);

    // Save the PDF
    $pdfFile = 'no_due_form_' . strtolower($name) . '.pdf';
    $pdf->Output(__DIR__ . '/' . $pdfFile, 'F');

    return [$pdfFile, $password];
}


// Database connection
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "krctnodues";
$conn = new mysqli($servername, $db_username, $db_password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_name = $_POST['student_name'];
    $birth_year = $_POST['birth_year']; // Get birth year from form

    // Prepare SQL statement to fetch student details
    $stmt = $conn->prepare("SELECT login1.email, login1.name, student1.department, student1.tutionfee, student1.hostelfee, student1.busfee, student1.miscellaneousfee, student1.messfee, student1.examfee, student1.libraryfee, student1.fine 
                            FROM login1 
                            JOIN student1 ON login1.name = student1.name 
                            WHERE login1.name = ?");
    $stmt->bind_param("s", $student_name);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $student_email = $row['email'];
        $department = $row['department'];
        $tutionfee = $row["tutionfee"];
        $hostelfee = $row["hostelfee"];
        $busfee = $row["busfee"];
        $miscellaneousfee = $row["miscellaneousfee"];
        $mess_fee = $row["messfee"];
        $exam_fee = $row["examfee"];
        $library_fee = $row["libraryfee"];
        $fine = $row["fine"];
        $total_amount = $tutionfee + $hostelfee + $busfee + $miscellaneousfee + $mess_fee + $exam_fee + $library_fee + $fine;
        $total_amount_in_words = numberToWords($total_amount);

        // Generate password-protected PDF
        list($pdf_filename, $pdf_password) = generateProtectedPDF($student_name, $department, $tutionfee, $hostelfee, $busfee, $miscellaneousfee, $mess_fee, $exam_fee, $library_fee, $fine, $total_amount, $total_amount_in_words, $birth_year);

        // Send email with PHPMailer
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'sasikanth15ab@gmail.com'; // Replace with your email
            $mail->Password = 'gnip jkow gstj ggso';  // Replace with your email password or App Password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->setFrom('sasikanth15ab@gmail.com', 'SASIKANTH U');
            $mail->addAddress($student_email);

            // Attach the generated PDF
            $mail->addAttachment(__DIR__ . '/' . $pdf_filename);

            $mail->isHTML(true);
            $mail->Subject = "Dues Approved";
            $mail->Body = "Dear $student_name, your dues have been approved. Attached is your no-due form. The password to open the PDF is: <b>$pdf_password</b>.";

            // Send email
            $mail->send();
            $_SESSION['status'] = "PDF generated, password-protected, and email sent successfully!";

            // Delete the temporary file after sending
            unlink(__DIR__ . '/' . $pdf_filename);
        } catch (Exception $e) {
            error_log("Mailer Error: " . $mail->ErrorInfo);
            $_SESSION['status'] = "Failed to send email. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        $_SESSION['status'] = "Student not found!";
    }

    $stmt->close();
    $conn->close();
    header("Location: admin_dashboard.php");
    exit();
}
?>





<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION["admin_username"])) {
    header("Location: admin_login.php"); // Redirect if not logged in
    exit;
}

// Database connection
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "krctnodues";

$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all student details from the student1 table
$result = $conn->query("SELECT name, department, tutionfee, hostelfee, busfee, miscellaneousfee, messfee, examfee, libraryfee, fine FROM student1");

// Check if the query was successful
if (!$result) {
    die("Query failed: " . $conn->error);
}

// Close the connection is delayed until after fetching the result set
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUa9rFfjlV1LOna+eMN7q5Brsc5f5Oh3f4CkCwKP3A0I9twAduS5u9U0pK7u" crossorigin="anonymous">

    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }

        .container {
            margin-top: 50px;
        }

        h1, h2 {
            text-align: center;
            color: #343a40;
        }

        .table {
            margin-top: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .table th {
            background-color: #007bff;
            color: white;
        }

        .table td, .table th {
            padding: 12px;
            text-align: center;
            vertical-align: middle;
        }

        .table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .status {
            padding: 10px;
            margin: 20px auto;
            text-align: center;
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
            border-radius: 5px;
            width: 80%;
        }

        .btn-approve {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        .btn-approve:hover {
            background-color: #218838;
        }

        .btn-logout {
            display: inline-block;
            background-color: #dc3545;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            text-align: center;
            transition: background-color 0.3s ease-in-out;
            margin-top: 20px;
            margin-left: auto;
            margin-right: auto;
            display: block;
        }

        .btn-logout:hover {
            background-color: #c82333;
        }
        

        /* Navbar container styling */
        .navbar {
    background-color: #333;
    padding: 10px 20px;
}

.container1 {
    max-width: 1200px;
    margin: 0 auto;
    display: flex;
    justify-content: flex-end;
}

.nav-list {
    list-style: none;
    display: flex;
    gap: 20px;
}

.nav-link {
    color: white;
    text-decoration: none;
    padding: 10px 15px;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

.nav-link:hover {
    background-color: #555;
}

    </style>
        <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
</head>

<body>
<nav class="navbar">
    <div class="container1">
        <ul class="nav-list">
            <li><a class="nav-link" href="create_user.php">Create User</a></li>
            <li><a class="nav-link" href="logout.php">Logout</a></li>
        </ul>
    </div>
</nav>



    <div class="container">
        <?php if (isset($_SESSION['status'])): ?>
            <div id="status-message" class="status">
                <?php 
                    echo htmlspecialchars($_SESSION['status']); 
                    unset($_SESSION['status']); // Clear the message after displaying
                ?>
            </div>
        <?php endif; ?>

        <h1>Welcome, <?php echo htmlspecialchars($_SESSION["admin_username"]); ?></h1>
        <h2>Student Details</h2>

        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Student Name</th>
                    <th>Department</th>
                    <th>Tution Fee</th>
                    <th>Hostel Fee</th>
                    <th>Bus Fee</th>
                    <th>Miscellaneous Fee</th>
                    <th>Mess Fee</th>
                    <th>Exam Fee</th>
                    <th>Library Fee</th>
                    <th>Fine</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['department']); ?></td>
                    <td><?php echo htmlspecialchars($row['tutionfee']); ?></td>
                    <td><?php echo htmlspecialchars($row['hostelfee']); ?></td>
                    <td><?php echo htmlspecialchars($row['busfee']); ?></td>
                    <td><?php echo htmlspecialchars($row['miscellaneousfee']); ?></td>
                    <td><?php echo htmlspecialchars($row['messfee']); ?></td>
                    <td><?php echo htmlspecialchars($row['examfee']); ?></td>
                    <td><?php echo htmlspecialchars($row['libraryfee']); ?></td>
                    <td><?php echo htmlspecialchars($row['fine']); ?></td>

                    <!-- Status logic -->
                    <td>
                        <?php 
                        if ($row['fine'] > 0) {
                            echo "<span class='text-danger'>Pending Dues</span>";
                        } else {
                            echo "<span class='text-success'>No Dues</span>";
                        }
                        ?>
                    </td>

                    <!-- Action button -->
                    <td>
                        <form action="approve_due.php" method="POST">
                            <input type="hidden" name="student_name" value="<?php echo htmlspecialchars($row['name']); ?>">
                            <button class="btn-approve" type="submit">Approve Dues</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <!-- <a href="logout.php" class="btn-logout">Logout</a> -->
    </div>

    <!-- Bootstrap JS (Optional) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+6py9uY+jpb2p6l4t/hfG99JtDigi"
        crossorigin="anonymous"></script>

    <script>
        // Automatically hide the success message after 3 seconds
        setTimeout(function () {
            var statusMessage = document.getElementById('status-message');
            if (statusMessage) {
                statusMessage.style.display = 'none';
            }
        }, 3000);
    </script>
</body>

</html>
